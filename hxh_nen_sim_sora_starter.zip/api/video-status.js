export default async function handler(req, res){
  const { id } = req.query || {};
  // Replace with your provider's job lookup. Here we just say 'succeeded' and return demo URL.
  const demo = process.env.DEMO_VIDEO_URL || 'https://files.catbox.moe/3q7t5x.mp4';
  return res.status(200).json({ status: 'succeeded', video_url: demo, id });
}
